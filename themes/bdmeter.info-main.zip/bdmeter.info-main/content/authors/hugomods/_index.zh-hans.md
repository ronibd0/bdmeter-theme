---
title: Hugo Modules Authors
description: Hugo 模块代码和文档的贡献者
images:
  - https://avatars.githubusercontent.com/u/128204519?s=200&v=4
socials:
  github: hugomods
  paypal: razonyang
  kofi: razonyang
  gmail: mailto:support@hugomods.com
---
