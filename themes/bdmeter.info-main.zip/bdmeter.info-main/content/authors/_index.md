---
title: Authors
menu:
  main:
    parent: blog
    params:
      icon:
        vendor: bs
        name: pencil
        color: '#0f5e97'
      description: Authors list.
---
