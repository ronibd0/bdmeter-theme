---
title: "Example Post with an Featured Image"
date: 2022-02-04T20:26:48+08:00
draft: false
featured: true
series:
  - Guide
categories:
  - Posts
tags:
  - Featured Image
authors:
  - razonyang
---

The example post with an featured image.

<!--more-->
