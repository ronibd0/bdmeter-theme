---
title: "带有特色图片的示例文章"
date: 2022-02-04T20:26:48+08:00
draft: false
featured: true
series:
  - 指南
categories:
  - 文章
tags:
  - 特色图片
authors:
  - razonyang
---

一篇带有特色图片的示例文章。

<!--more-->
