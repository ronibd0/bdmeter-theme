---
title: Featured Post without Image
Featured: true
date: 2022-09-10
---

A sample for showing how carousel handle featured posts that without images.
