---
date: 2022-03-06T22:42:23+08:00
title: 简介
nav_weight: 1
series:
  - 指南
nav_icon:
  vendor: bs
  name: book
  color: indigo
authors:
  - razonyang
---

一个可用于博客和文档站点的快速、响应式和功能丰富的 Hugo 主题。

## Greeting

```sh
echo "Hi there"
```
