---
date: 2022-03-06T22:42:23+08:00
title: Introduction
nav_weight: 1
series:
  - Guide
nav_icon:
  vendor: bs
  name: book
  color: indigo
authors:
  - razonyang
---

A fast, responsive and feature-rich Hugo theme for blog and documentations site.

<!--more-->

## Greeting

```sh
echo "Hi there"
```
