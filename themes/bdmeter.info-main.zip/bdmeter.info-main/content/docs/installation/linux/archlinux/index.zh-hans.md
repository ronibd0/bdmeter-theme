---
date: 2022-09-04T22:42:23+08:00
title: 安装到 Arch Linux
linkTitle: Arch Linux
series:
  - 指南
categories:
  - 安装
tags:
  - Linux
  - Arch Linux
images:
  - https://archlinux.org/static/logos/archlinux-logo-light-90dpi.d36c53534a2b.png?width=600&height=199
featured: true
authors:
  - razonyang
---

This guide show you how to install on Arch Linux.
