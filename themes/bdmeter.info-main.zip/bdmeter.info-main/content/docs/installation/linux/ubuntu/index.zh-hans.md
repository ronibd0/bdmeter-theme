---
date: 2022-10-16T22:42:23+08:00
title: 安装到 Ubuntu
linkTitle: Ubuntu
series:
  - 指南
categories:
  - 安装
tags:
  - Linux
  - Ubuntu
images:
featured: true
authors:
  - razonyang
---

This guide show you how to install on Ubuntu.
