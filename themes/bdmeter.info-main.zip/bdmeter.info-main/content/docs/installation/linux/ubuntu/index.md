---
date: 2022-10-16T22:42:23+08:00
title: Install on Ubuntu
linkTitle: Ubuntu
series:
  - Guide
categories:
  - Installation
tags:
  - Linux
  - Ubuntu
images:
featured: true
authors:
  - razonyang
---

This guide show you how to install on Ubuntu.
