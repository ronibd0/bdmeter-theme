---
date: 2022-09-06T22:42:23+08:00
title: 安装到 Windows 系统
linkTitle: Windows
series: 
  - 指南
categories:
  - 安装
tags:
  - Windows
images:
  - https://storage.googleapis.com/webdesignledger.pub.network/WDL/6f050e39-windows_10_logoblue.svg-copy_windows.jpg?width=1280&height=620
featured: true
authors:
  - razonyang
---

This guide show you how to install on Windows.
